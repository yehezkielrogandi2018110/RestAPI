package com.example.assassinapp;

import com.google.gson.annotations.SerializedName;

public class AssassinType{

	private String name;
	private String url;

	public String getName(){
		return name;
	}

	public String getUrl(){
		return url;
	}
}
